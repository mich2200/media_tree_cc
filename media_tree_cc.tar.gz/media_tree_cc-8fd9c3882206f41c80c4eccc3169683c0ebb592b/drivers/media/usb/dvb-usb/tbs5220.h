#ifndef _TBS5220_H_
#define _TBS5220_H_

#define DVB_USB_LOG_PREFIX "tbs5220"
#include "dvb-usb.h"

#define deb_xfer(args...) dprintk(dvb_usb_tbs5220_debug, 0x02, args)
#endif
