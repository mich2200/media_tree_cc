#ifndef _TBS5530_H_
#define _TBS5530_H_

#define DVB_USB_LOG_PREFIX "tbs5530"
#include "dvb-usb.h"

#define deb_xfer(args...) dprintk(dvb_usb_tbs5530_debug, 0x02, args)
#endif
