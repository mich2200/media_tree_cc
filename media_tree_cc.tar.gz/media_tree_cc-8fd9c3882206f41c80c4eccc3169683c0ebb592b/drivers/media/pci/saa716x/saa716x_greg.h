#ifndef __SAA716x_GREG_H
#define __SAA716x_GREG_H

struct saa716x_dev;

extern void saa716x_greg_save(struct saa716x_dev *saa716x);
extern void saa716x_greg_restore(struct saa716x_dev *saa716x);

#endif /* __SAA716x_GREG_H */
