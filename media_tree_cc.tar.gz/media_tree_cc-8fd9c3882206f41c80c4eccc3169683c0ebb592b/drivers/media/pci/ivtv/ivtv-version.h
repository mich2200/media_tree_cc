/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
    ivtv driver version information
    Copyright (C) 2005-2007  Hans Verkuil <hverkuil@xs4all.nl>

 */

#ifndef IVTV_VERSION_H
#define IVTV_VERSION_H

#define IVTV_DRIVER_NAME "ivtv"
#define IVTV_VERSION "1.4.3"

#endif
